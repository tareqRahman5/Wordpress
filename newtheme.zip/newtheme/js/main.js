form.addEventListener('submit',(e)=>{
    let messages=[]
    if(s.value===''|| s.value==null){
        messages.push('Please fill out the field')
    }
}



)