<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
<link href="<?php echo get_template_directory_uri() ?>/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo get_template_directory_uri() ?>/css/custom.css" rel="stylesheet">


<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div class="header_area">
    <div class="container">
        <div class="row">
        
        <a href="<?php echo site_url();?>"><img src="<?php echo get_theme_mod('tareq_logo'); ?>" alt=""></a>
        </div>
    </div>
</div>
        



  <div class="container-fluid nn sticky-top">
  <nav class="navbar navbar-expand-lg navbar-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse container" id="navbarSupportedContent">
 
    <?php 
    wp_nav_menu( array('theme_location' =>'main_menu',
    'depth'=> 2,
    'container'=>'div',
    'container_class'=>'collapse navbar-collapse',
    'container_id' =>'navbarSupportedContent',
    'menu_class'=>'navbar-nav nav',
    'fallback_cb'=>'WP_Bootstrap_Navwalker::fallback',
    'walker'=> new WP_Bootstrap_Navwalker(),

));
    ?>


<form role="search" method="get" id="searchform"
    class="searchform d-flex" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <div>
        <label class="screen-reader-text" for="s"><?php _x( 'Search for:', 'label' ); ?></label>
        <input type="text" value="<?php echo get_search_query(); ?>" name="s" id="s" />
        <input type="submit" id="searchsubmit"
            value="<?php echo esc_attr_x( 'Search', 'submit button' ); ?>" />
    </div>
</form>
   </div>
    
    </nav>
  </div>



        </div>
    </div>


<div class="container-fluid">
  <div class="row">




            <div class="col-md-8 col-sm-8 single">
                        <?php while ( have_posts() ) : ?>
                            <?php the_post(); ?>
                            
                            <img src="<?php the_post_thumbnail_url();?>" alt="" srcset="" class="img-fluid">
                            <h2 class="headlinemargin" ><?php the_title(); ?></h2> 
                            <small><?php the_time('F jS, Y'); ?></small>
                            <?php the_content();?>
                                
                    <?php wpb_set_post_views(get_the_ID());?>

                        <?php endwhile; ?>

            </div>

            





            <div class="col-md-4 col-sm-4 other-section single">
  
  <ul class="nav nav-tabs">
  <li class="nav-item latest"><a data-bs-toggle="tab" class="nav-link active" href="#edu">সর্বশেষ</a></li>
  <li class="nav-item latest"><a data-bs-toggle="tab" class="nav-link" href="#skill">সর্বাধিক পঠিত</a></li>
    </ul>

    <div class="tab-content widthscroll">
     <div id="edu" class="tab-pane active">
       
     <?php $query = new WP_Query( 'cat=-1&posts_per_page=15' ); ?>
 <?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); ?>

 <div class="col-12">
                    <div class="row">
                  <div class="col-4"><a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url();?>" alt="" srcset="" class="img-fluid"></a></div>
                  <div class="col-8 latehead"><p><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></p></div>
                    </div>  
                </div> 

 <?php endwhile; 
 wp_reset_postdata();
 else : ?>
 <p><?php esc_html_e( 'Sorry, no posts matched your criteria.' ); ?></p>
 <?php endif; ?>

 

     </div>





     <div id="skill" class="tab-pane fade">

     <?php 
$popularpost = new WP_Query( array( 'posts_per_page' => 15, 'meta_key' => 'wpb_post_views_count', 'orderby' => 'meta_value_num', 'order' => 'DESC'  ) );
while ( $popularpost->have_posts() ) : $popularpost->the_post();
 ?>

   
<div class="col-12">
                    <div class="row">
                  <div class="col-4"><a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url();?>" alt="" srcset="" class="img-fluid"></a></div>
                  <div class="col-8 latehead"><p><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></p></div>
                    </div>  
                </div> 


 <?php
endwhile;
?>



     </div>

     
    </div>

</div>


            








    </div>

</div>



 
   

      

<div class="container-fluid">
  <div class="row all-footer">
    <div class="footer">
      <ul>
        <li><a href="http://localhost/wordpress/about-us/">About Us</a></li>
        <li><a href="http://localhost/wordpress/privacy-policy/">Privacy Policy</a></li>
        <li><a href="http://localhost/wordpress/contact-us/">Contact Us</a></li>
        <li><a href="http://localhost/wordpress/terms-and-condition/">Terms & Condition</a></li>
        <li><a href="http://localhost/wordpress/privacy-policy-2/">Privacy Policy</a></li>
      </ul>
    </div>

    <div class="footer-2">
      <div class="row">
        <div class="col-md-4 col-sm-4">
            <ul>
            <li> অফিস ঠিকানা : ৯৫ সোহরাওয়ার্দী এভিনিউ, বারিধারা ডিপ্লোমেটিক জোন, ঢাকা ১২১২</li>
            <li class="bi bi-telephone"><a href="tel:+15555551212"> হটলাইন : +৮৮০ ৯৬১৩ ৬৭৮৬৭৮</a></li>
            
            <li class="bi bi-telephone"><a href="tel:+15555551212"> বিঞ্জাপনের জন্য যোগাযোগ : 01575380353</a></li>
            <li class="bi bi-telephone"><a href="tel:+15555551212"> নিউজের জন্য যোগাযোগ : 01575380353</a></li>
            <li class="bi bi-telephone"><a href="tel:+15555551212"> সাধারন জিঞ্জাসা : 01575380353</a></li>
          </ul> 
      </div>

      <div class="col-4"></div>

<div class="col-md-4 col-sm-4">
      <ul class="pub">
        <li>সম্পাদক: তারেক রহমান </li>
        <li class="bi bi-envelope-fill"> ইমেইল : tareq.bes@gmail.com</li>
        
        <li class="bi bi-envelope-fill"> নিউজ : tareq.bes@gmail.com</li>
        <li class="bi bi-envelope-fill"> মফস্বল নিউজ: tareq.bes@gmail.com</li>
        <li class="bi bi-envelope-fill"> Email: tareq.bes@gmail.com</li>
      </ul> 
  </div>

      </div>
    </div>
  </div>
</div>
      

   





<script src="<?php echo get_template_directory_uri() ?>/js/bootstrap.js"></script>
<script src="<?php echo get_template_directory_uri() ?>/js/main.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>