<?php
require_once get_template_directory().'/navwalker.php';
add_theme_support('post-thumbnails');

function tareq_customizar_register($wp_customize){
$wp_customize->add_section('tareq_header_area', array(
    'title'=>__('Header Area', 'tareqrahman'),
    'description'=> 'update your header area.'

));
$wp_customize->add_setting('tareq_logo', array(
'default' => get_bloginfo('template_directory'.'/img/logo.png')
));
$wp_customize-> add_control(new WP_Customize_Image_Control($wp_customize, 'tareq_logo', array(
    'label' =>'Logo Upload',
    'setting' => 'tareq_logo',
    'section' =>'tareq_header_area',
)));
}
add_action('customize_register','tareq_customizar_register'); 


//Menu register

register_nav_menu('main_menu', __('Main Menu','tareqrahman'));


function wpb_set_post_views($postID) {
    $count_key = 'wpb_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
//To keep the count accurate, lets get rid of prefetching
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);



function SearchFilter($query) {
    // If 's' request variable is set but empty
    if (isset($_GET['s']) && empty($_GET['s']) && $query->is_main_query()){
        $query->is_search = true;
        $query->is_home = false;
    }
    return $query;}
add_filter('pre_get_posts','SearchFilter');