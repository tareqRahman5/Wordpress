<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
<link href="<?php echo get_template_directory_uri() ?>/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo get_template_directory_uri() ?>/css/custom.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div class="header_area">
    <div class="container">
        <div class="row">
        
        <a href="<?php echo site_url();?>"><img src="<?php echo get_theme_mod('tareq_logo'); ?>" alt=""></a>
        </div>
    </div>
</div>
        



  <div class="container-fluid nn">
  <nav class="navbar navbar-expand-lg navbar-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse container" id="navbarSupportedContent">
 
    <?php 
    wp_nav_menu( array('theme_location' =>'main_menu',
    'depth'=> 2,
    'container'=>'div',
    'container_class'=>'collapse navbar-collapse',
    'container_id' =>'navbarSupportedContent',
    'menu_class'=>'navbar-nav nav',
    'fallback_cb'=>'WP_Bootstrap_Navwalker::fallback',
    'walker'=> new WP_Bootstrap_Navwalker(),

));
    ?>


<form role="search" method="get" id="searchform"
    class="searchform d-flex" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <div>
        <label class="screen-reader-text" for="s"><?php _x( 'Search for:', 'label' ); ?></label>
        <input type="text" value="<?php echo get_search_query(); ?>" name="s" id="s" />
        <input type="submit" id="searchsubmit"
            value="<?php echo esc_attr_x( 'Search', 'submit button' ); ?>" />
    </div>
</form>
   </div>
    
    </nav>
  </div>



        </div>
    </div>

   <br>

<div class="container-fluid">
  <div class="row">


<h2>Contact Us</h2>

     <div class=".col-md-4 col-sm-4">
            <ul class="contact">
                    <li>
                    <div class="row">
                            <div class="col-md-2">
                            <i class="bi bi-phone alliconstyle"></i>
                            </div>
                                <div class="col-md-10 allicon">
                                <h6>মোবাইল</h6>
                                <a href="tel:01317248079">01317248079</a>
                                </div>
                            </div>
                    </li>
            </ul>


            <ul class="contact">
                    <li>
                    <div class="row">
                            <div class="col-md-2">
                            <i class="bi bi-whatsapp alliconstyle"></i>
                            </div>
                                <div class="col-md-10 allicon">
                                <h6>হোয়াট্স অ্যাপ </h6>
                                <a href="tel:01317248079">01317248079</a>
                                </div>
                            </div>
                    </li>
            </ul>
     </div>








     <div class=".col-md-4 col-sm-4">
            <ul class="contact">
                    <li>
                    <div class="row">
                            <div class="col-md-2">
                            <i class="bi bi-telephone-inbound alliconstyle"></i>
                            </div>
                                <div class="col-md-10 allicon">
                                <h6>ফোন</h6>
                                <a href="tel:096555253">8096555253</a>
                                </div>
                            </div>
                    </li>
            </ul>


            <ul class="contact">
                    <li>
                    <div class="row">
                            <div class="col-md-2">
                            <i class="bi bi-envelope alliconstyle"></i>
                            </div>
                                <div class="col-md-10 allicon">
                                <h6>ই-মেইল</h6>
                                <a class="address" href="mailto:tareq.bes@gmail.com">tareq.bes@gmail.com</a>
                                </div>
                            </div>
                    </li>
            </ul>
     </div>







     <div class=".col-md-4 col-sm-4">
            <ul class="contact">
                    <li>
                    <div class="row">
                            <div class="col-md-2">
                            <i class="bi bi-geo-alt-fill alliconstyle"></i>
                            </div>
                                <div class="col-md-10 allicon">
                                <h6>ঠিকানা</h6>
                                <p class="address">৯৫ সোহরাওয়ার্দী এভিনিউ বারিধারা ডিপ্লোমেটিক জোন, ঢাকা ১২১২</p>
                                </div>
                            </div>
                    </li>
            </ul>

     </div>









    </div>

</div>



 
   






<div class="container-fluid">
  <div class="row all-footer">
    <div class="footer">
      <ul>
        <li><a href="http://localhost/wordpress/about-us/">About Us</a></li>
        <li><a href="http://localhost/wordpress/privacy-policy/">Privacy Policy</a></li>
        <li><a href="http://localhost/wordpress/contact-us/">Contact Us</a></li>
        <li><a href="http://localhost/wordpress/terms-and-condition/">Terms & Condition</a></li>
        <li><a href="http://localhost/wordpress/privacy-policy-2/">Privacy Policy</a></li>
      </ul>
    </div>

    <div class="footer-2">
      <div class="row">
        <div class="col-md-4 col-sm-4">
            <ul>
            <li> অফিস ঠিকানা : ৯৫ সোহরাওয়ার্দী এভিনিউ, বারিধারা ডিপ্লোমেটিক জোন, ঢাকা ১২১২</li>
            <li class="bi bi-telephone"><a href="tel:+15555551212"> হটলাইন : +৮৮০ ৯৬১৩ ৬৭৮৬৭৮</a></li>
            
            <li class="bi bi-telephone"><a href="tel:+15555551212"> বিঞ্জাপনের জন্য যোগাযোগ : 01575380353</a></li>
            <li class="bi bi-telephone"><a href="tel:+15555551212"> নিউজের জন্য যোগাযোগ : 01575380353</a></li>
            <li class="bi bi-telephone"><a href="tel:+15555551212"> সাধারন জিঞ্জাসা : 01575380353</a></li>
          </ul> 
      </div>

      <div class="col-4"></div>

<div class="col-md-4 col-sm-4">
      <ul class="pub">
        <li>সম্পাদক: তারেক রহমান </li>
        <li class="bi bi-envelope-fill"> ইমেইল : tareq.bes@gmail.com</li>
        
        <li class="bi bi-envelope-fill"> নিউজ : tareq.bes@gmail.com</li>
        <li class="bi bi-envelope-fill"> মফস্বল নিউজ: tareq.bes@gmail.com</li>
        <li class="bi bi-envelope-fill"> Email: tareq.bes@gmail.com</li>
      </ul> 
  </div>

      </div>
    </div>
  </div>
</div>

      

      

   





<script src="<?php echo get_template_directory_uri() ?>/js/bootstrap.js"></script>
<script src="<?php echo get_template_directory_uri() ?>/js/main.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>